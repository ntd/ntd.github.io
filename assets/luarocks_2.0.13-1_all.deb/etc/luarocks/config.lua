rocks_servers = {
   [[http://luarocks.org/repositories/rocks]]
}

rocks_trees = {
   home..[[/.luarocks]],
   [[/usr/local]]
}
