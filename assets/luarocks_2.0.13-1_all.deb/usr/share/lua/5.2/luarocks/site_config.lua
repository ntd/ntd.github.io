local popen = io.popen
module("luarocks.site_config")
LUAROCKS_PREFIX=[[/usr]]
LUA_INCDIR=[[/usr/include/lua5.2]]
LUA_LIBDIR=[[/usr/local/lib]]
LUA_BINDIR=[[/usr/bin]]
LUAROCKS_SYSCONFDIR=[[/etc/luarocks]]
LUAROCKS_ROCKS_TREE=[[/usr/local/]]
LUA_DIR_SET=true
LUAROCKS_UNAME_S=(popen("uname -s"):read("*a"):gsub("\n",""))
LUAROCKS_UNAME_M=(popen("uname -m"):read("*a"):gsub("\n",""))
LUAROCKS_DOWNLOADER=[[wget]]
LUAROCKS_MD5CHECKER=[[md5sum]]
